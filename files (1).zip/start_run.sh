#!/usr/bin/env bash
# start_run.sh - installs deps (if needed), ensures .env, prepares data directory, then starts the bot in background.
# Usage: chmod +x start_run.sh && ./start_run.sh

set -e

# Move to script directory
cd "$(dirname "$0")"

# Install production dependencies if node_modules missing
if [ ! -d node_modules ]; then
  echo "[start_run] Installing dependencies (production)..."
  if [ -f package-lock.json ]; then
    npm ci --only=production
  else
    npm install --only=production
  fi
else
  echo "[start_run] node_modules exists, skipping install."
fi

# Ensure .env exists (prefer .env.production)
if [ ! -f .env ]; then
  if [ -f .env.production ]; then
    echo "[start_run] Copying .env.production -> .env"
    cp .env.production .env
  else
    echo "[start_run] Warning: no .env or .env.production found. Create one from .env.production.example before starting."
  fi
fi

# Prepare persistent data directory for auth/logs
mkdir -p data
# If auth_info.json exists in root and data/auth_info.json missing, move it to persistent folder
if [ -f auth_info.json ] && [ ! -f data/auth_info.json ]; then
  echo "[start_run] Moving auth_info.json -> data/auth_info.json"
  mv auth_info.json data/auth_info.json || true
fi

# Symlink data/auth_info.json back to root so Baileys finds it (if not already present)
if [ -f data/auth_info.json ] && [ ! -f auth_info.json ]; then
  ln -s "$(pwd)/data/auth_info.json" "$(pwd)/auth_info.json" || true
fi

# Ensure log file exists
mkdir -p logs
touch data/bot.log

# Start bot in background using nohup, writing stdout/stderr to data/bot.log
echo "[start_run] Starting bot with nohup. Logs -> data/bot.log"
nohup node index.js >> data/bot.log 2>&1 &

# Print last 40 lines of log for QR scan convenience
sleep 1
echo "---- last lines of data/bot.log ----"
tail -n 40 data/bot.log || true
echo "------------------------------------"
echo "Bot started (background). Use 'tail -f data/bot.log' to follow logs."