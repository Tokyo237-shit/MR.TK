// sessionStore.js
// Simple Redis-backed session store (same as earlier)

const IORedis = require('ioredis');
const redisUrl = process.env.REDIS_URL || null;

const redis = redisUrl ? new IORedis(redisUrl) : new IORedis({
  host: process.env.REDIS_HOST || '127.0.0.1',
  port: process.env.REDIS_PORT ? parseInt(process.env.REDIS_PORT, 10) : 6379,
  password: process.env.REDIS_PASSWORD || undefined,
});

const SESSION_TTL_SECONDS = process.env.SESSION_TTL_SECONDS ? parseInt(process.env.SESSION_TTL_SECONDS, 10) : 300; // default 5 minutes
const PREFIX = process.env.SESSION_KEY_PREFIX || 'wa_session:';

function keyFor(jid) {
  return `${PREFIX}${jid}`;
}

async function setSession(jid, session) {
  const k = keyFor(jid);
  const payload = JSON.stringify(session);
  await redis.set(k, payload, 'EX', SESSION_TTL_SECONDS);
}

async function getSession(jid) {
  const k = keyFor(jid);
  const raw = await redis.get(k);
  if (!raw) return null;
  try {
    return JSON.parse(raw);
  } catch (err) {
    console.error('Failed to parse session JSON for', jid, err);
    return null;
  }
}

async function clearSession(jid) {
  const k = keyFor(jid);
  await redis.del(k);
}

async function touchSession(jid) {
  const k = keyFor(jid);
  const exists = await redis.exists(k);
  if (exists) {
    await redis.expire(k, SESSION_TTL_SECONDS);
  }
}

module.exports = {
  setSession,
  getSession,
  clearSession,
  touchSession,
  _redisClient: redis
};