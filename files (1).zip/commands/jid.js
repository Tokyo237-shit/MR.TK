// commands/jid.js
module.exports = {
  name: 'jid',
  description: 'Show your jid',
  category: 'general',
  execute: async ({ raw, reply }) => {
    const jid = raw.key && raw.key.participant ? raw.key.participant : raw.key.remoteJid;
    return reply(`Your JID: ${jid}`);
  }
};