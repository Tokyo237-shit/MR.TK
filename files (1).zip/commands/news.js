// commands/news.js
module.exports = {
  name: 'news',
  description: 'Top news (stub)',
  category: 'general',
  execute: async ({ reply }) => {
    // Integrate with a news API for real headlines.
    return reply('Top news: (not implemented)');
  }
};