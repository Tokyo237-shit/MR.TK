// commands/delete.js
module.exports = {
  name: 'delete',
  aliases: ['del'],
  description: 'Delete a message (reply to message) - requires fromMe or proper privileges',
  category: 'admin',
  execute: async ({ sock, raw, reply }) => {
    try {
      const ctx = raw.message?.extendedTextMessage?.contextInfo;
      const quoted = ctx && ctx.stanzaId && ctx.participant;
      if (!quoted) return reply('Reply to a message to delete it with .delete (only works for your own messages or with proper admin rights).');
      const key = {
        remoteJid: raw.key.remoteJid,
        id: ctx.stanzaId,
        participant: ctx.participant
      };
      await sock.sendMessage(raw.key.remoteJid, { delete: key });
      return reply('Deletion attempted.');
    } catch (err) {
      console.error(err);
      return reply('Failed to delete message.');
    }
  }
};