// commands/demote.js
module.exports = {
  name: 'demote',
  description: 'Demote an admin to member (group only)',
  category: 'admin',
  groupOnly: true,
  adminOnly: true,
  execute: async ({ sock, jid, args, raw, reply }) => {
    const mentioned = raw.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
    const target = (mentioned[0] || args[0]);
    if (!target) return reply('Usage: .demote @user or reply to message and use .demote');
    const targetJid = target.includes('@') ? target : `${target.replace(/\D/g,'')}@s.whatsapp.net`;
    try {
      await sock.groupParticipantsUpdate(jid, [targetJid], 'demote');
      return reply(`Demoted ${targetJid}`);
    } catch (err) {
      console.error(err);
      return reply('Failed to demote (maybe missing permissions).');
    }
  }
};