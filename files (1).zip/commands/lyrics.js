// commands/lyrics.js
module.exports = {
  name: 'lyrics',
  description: 'Lookup song lyrics (stub)',
  category: 'downloader',
  execute: async ({ args, reply }) => {
    if (!args.length) return reply('Usage: .lyrics <song title>');
    return reply('Lyrics lookup not implemented here.');
  }
};