// commands/promote.js
module.exports = {
  name: 'promote',
  description: 'Promote a member to admin (group only)',
  category: 'admin',
  groupOnly: true,
  adminOnly: true,
  execute: async ({ sock, jid, args, raw, reply }) => {
    // Try to find mentioned participant or arg
    const mentioned = raw.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
    const target = (mentioned[0] || args[0]);
    if (!target) return reply('Usage: .promote @user or reply to message and use .promote');
    const targetJid = target.includes('@') ? target : `${target.replace(/\D/g,'')}@s.whatsapp.net`;
    try {
      await sock.groupParticipantsUpdate(jid, [targetJid], 'promote');
      return reply(`Promoted ${targetJid}`);
    } catch (err) {
      console.error(err);
      return reply('Failed to promote (maybe missing permissions).');
    }
  }
};