// commands/url.js
module.exports = {
  name: 'url',
  description: 'Shorten or show URL (stub)',
  category: 'general',
  execute: async ({ args, reply }) => {
    if (!args.length) return reply('Usage: .url <link>');
    return reply('URL shortening not implemented in this example.');
  }
};