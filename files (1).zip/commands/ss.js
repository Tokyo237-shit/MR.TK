// commands/ss.js
module.exports = {
  name: 'ss',
  description: 'Screenshot URL (stub)',
  category: 'general',
  execute: async ({ args, reply }) => {
    if (!args.length) return reply('Usage: .ss <link>');
    return reply('Screenshot functionality not implemented. Use a web-screenshot API.');
  }
};