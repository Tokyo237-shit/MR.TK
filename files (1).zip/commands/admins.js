// commands/admins.js
module.exports = {
  name: 'admins',
  aliases: ['staff'],
  description: 'List group admins (group only)',
  category: 'admin',
  groupOnly: true,
  execute: async ({ sock, jid, reply }) => {
    try {
      const meta = await sock.groupMetadata(jid);
      const admins = (meta.participants || []).filter(p => p.admin).map(p => p.id);
      if (!admins.length) return reply('No admins found.');
      return reply(`Admins:\n${admins.join('\n')}`);
    } catch (err) {
      return reply('Failed to fetch admins.');
    }
  }
};