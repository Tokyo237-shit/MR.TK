// commands/death.js
// Safe .death command: records moderated reports in Redis (non-abusive).
const reportsStore = require('../reportsStore');

module.exports = {
  name: 'death',
  description: 'Record an incident report for owner review (non-abusive)',
  category: 'safety',
  execute: async ({ sock, jid, args, raw, reply }) => {
    if (!args || args.length === 0) {
      return reply('Usage: .death <phone_or_jid> [reason]\nThis records a report for owner review; it does NOT perform any mass-reporting.');
    }
    let target = args[0].trim();
    if (!target.includes('@')) {
      const digits = target.replace(/\D/g, '');
      if (!digits) return reply('Could not parse target. Provide phone or full JID.');
      target = `${digits}@s.whatsapp.net`;
    }
    const reason = args.slice(1).join(' ') || 'No reason provided';
    const res = await reportsStore.addReport(target, jid, reason);
    if (!res.success && res.reason === 'rate_limited') {
      return reply('You are sending reports too quickly. Please wait before reporting again.');
    }
    if (!res.success) return reply('Failed to record report.');
    await reply(`Recorded report for ${target} (id:${res.id}). Total reports for contact: ${res.count}`);
    const notifyThreshold = process.env.REPORT_NOTIFY_THRESHOLD ? parseInt(process.env.REPORT_NOTIFY_THRESHOLD, 10) : 10;
    if (res.count >= notifyThreshold) {
      try {
        const owner = process.env.OWNER_JID || '237696777393@s.whatsapp.net';
        await sock.sendMessage(owner, { text: `⚠️ Reports threshold reached for ${target}. Count: ${res.count}` });
      } catch (err) {
        console.error('Failed to notify owner', err);
      }
    }
  }
};