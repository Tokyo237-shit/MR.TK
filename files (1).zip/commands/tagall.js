// commands/tagall.js
module.exports = {
  name: 'tagall',
  description: 'Mention all group members (admin only)',
  category: 'admin',
  groupOnly: true,
  adminOnly: true,
  execute: async ({ sock, jid, reply }) => {
    try {
      const meta = await sock.groupMetadata(jid);
      const participants = (meta.participants || []).map(p => p.id);
      const text = `@everyone`;
      await sock.sendMessage(jid, { text, mentions: participants });
      return reply('Tagged all members.');
    } catch (err) {
      console.error(err);
      return reply('Failed to tag all.');
    }
  }
};