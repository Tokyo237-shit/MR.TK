// commands/joke.js
module.exports = {
  name: 'joke',
  description: 'Tell a random joke',
  category: 'fun',
  execute: async ({ reply }) => {
    const jokes = [
      "Why don't programmers like nature? It has too many bugs.",
      "Why do programmers prefer dark mode? Because light attracts bugs.",
      "I told my computer I needed a break, and it said: 'No problem — I'll go to sleep.'"
    ];
    const j = jokes[Math.floor(Math.random() * jokes.length)];
    return reply(j);
  }
};