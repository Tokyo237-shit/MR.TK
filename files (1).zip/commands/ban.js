// commands/ban.js
module.exports = {
  name: 'ban',
  description: 'Ban user (stub) — owner-only',
  category: 'admin',
  ownerOnly: true,
  execute: async ({ args, reply }) => {
    return reply('Ban command stub. Implement persistent ban list or group-level ban via admin actions.');
  }
};