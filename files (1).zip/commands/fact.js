// commands/fact.js
module.exports = {
  name: 'fact',
  description: 'Random fact',
  category: 'fun',
  execute: async ({ reply }) => {
    const facts = [
      "Honey never spoils.",
      "Octopuses have three hearts."
    ];
    return reply(facts[Math.floor(Math.random() * facts.length)]);
  }
};