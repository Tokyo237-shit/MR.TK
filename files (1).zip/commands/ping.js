// commands/ping.js
module.exports = {
  name: 'ping',
  description: 'Check latency',
  category: 'general',
  execute: async ({ sock, jid, reply }) => {
    const t0 = Date.now();
    await reply('Pinging...');
    const latency = Date.now() - t0;
    await reply(`Pong — latency: ${latency}ms`);
  }
};