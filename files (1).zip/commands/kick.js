// commands/kick.js
module.exports = {
  name: 'kick',
  description: 'Remove a member from group (admin only)',
  category: 'admin',
  groupOnly: true,
  adminOnly: true,
  execute: async ({ sock, jid, args, raw, reply }) => {
    const mentioned = raw.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
    const target = (mentioned[0] || args[0]);
    if (!target) return reply('Usage: .kick @user or reply to message and use .kick');
    const targetJid = target.includes('@') ? target : `${target.replace(/\D/g,'')}@s.whatsapp.net`;
    try {
      await sock.groupParticipantsUpdate(jid, [targetJid], 'remove');
      return reply(`Kicked ${targetJid}`);
    } catch (err) {
      console.error(err);
      return reply('Failed to kick (maybe missing permissions).');
    }
  }
};