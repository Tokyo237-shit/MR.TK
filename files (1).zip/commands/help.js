// commands/help.js
module.exports = {
  name: 'help',
  aliases: ['menu'],
  description: 'Show help/menu',
  category: 'general',
  execute: async ({ sock, jid, args, raw, reply }) => {
    // dynamic help built by command-loader is not available directly,
    // but we give a friendly user-oriented menu. For full auto-help,
    // restart with SIGHUP after adding/removing commands.
    const text = `
Available commands (sample):
.help / .menu - show this message
.ping - latency
.alive - bot info
.owner - show owner
.survey - start a survey
.death - record an incident (non-abusive)
.more - check README for full command list
`;
    return reply(text.trim());
  }
};