// commands/attp.js
module.exports = {
  name: 'attp',
  description: 'ATTp (text-to-sticker) stub',
  category: 'image',
  execute: async ({ args, reply }) => {
    if (!args.length) return reply('Usage: .attp <text>');
    return reply('ATTp (sticker generator) not implemented in this example.');
  }
};