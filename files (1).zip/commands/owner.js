// commands/owner.js
module.exports = {
  name: 'owner',
  description: 'Show owner contact',
  category: 'general',
  execute: async ({ sock, jid, reply }) => {
    const owner = process.env.OWNER_JID || '237696777393@s.whatsapp.net';
    return reply(`Bot owner: ${owner}`);
  }
};