// commands/alive.js
module.exports = {
  name: 'alive',
  aliases: [],
  description: 'Bot status and version',
  category: 'general',
  execute: async ({ sock, jid, reply }) => {
    const version = process.env.BOT_VERSION || '2.2.2';
    const owner = process.env.OWNER_JID || '237696777393@s.whatsapp.net';
    const text = `🤖 MR•TK BOT  🩸\n\nVersion: ${version}\nOwner: ${owner}\nStatus: online`;
    return reply(text);
  }
};