// commands/vv.js
module.exports = {
  name: 'vv',
  description: 'Anti view-once stub (informational)',
  category: 'general',
  execute: async ({ reply }) => {
    return reply('Anti view-once functionality is not provided by this example (and may violate privacy).');
  }
};