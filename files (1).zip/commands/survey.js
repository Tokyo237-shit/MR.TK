// commands/survey.js
// Survey is a multi-step flow handled via session store if desired.
const { setSession } = require('../sessionStore');

module.exports = {
  name: 'survey',
  description: 'Start a 2-step survey',
  category: 'general',
  execute: async ({ sock, jid, reply }) => {
    const session = { command: 'survey', step: 1, data: {} };
    await setSession(jid, session);
    return reply('Survey started. What is your name?');
  },
  handleSession: async ({ sock, jid, args }, session) => {
    // args is an array with the latest text
    const text = (args && args[0]) ? args[0] : '';
    if (session.step === 1) {
      session.data.name = text.trim();
      session.step = 2;
      await setSession(jid, session);
      await sock.sendMessage(jid, { text: `Nice to meet you, ${session.data.name}! How old are you? (send a number)` });
      return true;
    }
    if (session.step === 2) {
      const age = parseInt(text.trim(), 10);
      if (Number.isNaN(age) || age <= 0) {
        await sock.sendMessage(jid, { text: 'Please enter a valid age as a number.' });
        return true;
      }
      session.data.age = age;
      await sock.sendMessage(jid, { text: `Survey complete!\nName: ${session.data.name}\nAge: ${session.data.age}` });
      return false;
    }
    return false;
  }
};