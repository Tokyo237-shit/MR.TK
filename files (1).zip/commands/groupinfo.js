// commands/groupinfo.js
module.exports = {
  name: 'groupinfo',
  description: 'Show group info (group only)',
  category: 'general',
  groupOnly: true,
  execute: async ({ sock, jid, reply }) => {
    try {
      const meta = await sock.groupMetadata(jid);
      const subject = meta.subject || '';
      const desc = meta.desc || '';
      const participants = meta.participants ? meta.participants.length : 0;
      return reply(`Group: ${subject}\nDescription: ${desc}\nMembers: ${participants}`);
    } catch (err) {
      return reply('Failed to fetch group metadata.');
    }
  }
};