// commands/mute.js
module.exports = {
  name: 'mute',
  description: 'Mute group (stub)',
  category: 'admin',
  groupOnly: true,
  adminOnly: true,
  execute: async ({ args, reply }) => {
    return reply('Mute group not implemented. You can implement via group settings API if available.');
  }
};