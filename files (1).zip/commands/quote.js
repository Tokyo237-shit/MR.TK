// commands/quote.js
module.exports = {
  name: 'quote',
  description: 'Send an inspirational quote',
  category: 'fun',
  execute: async ({ reply }) => {
    const quotes = [
      "Code is like humor. When you have to explain it, it’s bad. — Cory House",
      "Simplicity is the soul of efficiency. — Austin Freeman"
    ];
    return reply(quotes[Math.floor(Math.random() * quotes.length)]);
  }
};