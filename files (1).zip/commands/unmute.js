// commands/unmute.js
module.exports = {
  name: 'unmute',
  description: 'Unmute group (stub)',
  category: 'admin',
  groupOnly: true,
  adminOnly: true,
  execute: async ({ reply }) => {
    return reply('Unmute group not implemented in this example.');
  }
};