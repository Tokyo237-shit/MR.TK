// commands/8ball.js
module.exports = {
  name: '8ball',
  aliases: ['8ball'],
  description: 'Magic 8-ball answers',
  category: 'fun',
  execute: async ({ args, reply }) => {
    if (!args.length) return reply('Ask a question: .8ball <question>');
    const answers = [
      'It is certain.',
      'Reply hazy, try again.',
      'Don’t count on it.',
      'My sources say no.'
    ];
    return reply(answers[Math.floor(Math.random() * answers.length)]);
  }
};