// commands.js
// Command parsing and session-based flow handlers, plus safe reporting (non-abusive).

const { setSession, getSession, clearSession } = require('./sessionStore');
const reportsStore = require('./reportsStore');

const OWNER_JID = process.env.OWNER_JID || '237696777393@s.whatsapp.net'; // provided owner JID

/**
 * handleCommand(sock, jid, command, args, rawMsg)
 * - sock: Baileys socket
 * - jid: remote JID (user)
 * - command: string like '/survey' or '.death'
 * - args: array of args
 * - rawMsg: original message object (optional)
 */
async function handleCommand(sock, jid, command, args, rawMsg) {
  switch (command) {
    case '/start':
    case '.start':
      await sock.sendMessage(jid, {
        text:
          'Welcome! Available commands:\n' +
          '/start or .start - welcome message\n' +
          '/help or .help - show commands\n' +
          '/survey or .survey - start a short multi-step survey\n' +
          '/death or .death <number|jid> - file a safe incident report (owner/admin only can view)\n' +
          '/cancel or .cancel - cancel active flow'
      });
      break;

    case '/help':
    case '.help':
    case '.menu':
      await sock.sendMessage(jid, {
        text:
          'Commands:\n' +
          '.survey — start a 2-step survey (name, age)\n' +
          '.death <number|jid> <reason?> — record an incident report (non-destructive)\n' +
          '.reports <number|jid> — (owner only) view reports for a contact\n' +
          '.clearreports <number|jid> — (owner only) clear reports for a contact\n' +
          '.cancel — cancel any active session\n' +
          'Send any text otherwise to get an echo.'
      });
      break;

    case '/cancel':
    case '.cancel':
      await clearSession(jid);
      await sock.sendMessage(jid, { text: 'Cancelled any active session.' });
      break;

    case '/survey':
    case '.survey':
      // initialize a survey session
      {
        const session = {
          command: 'survey',
          step: 1,
          data: {}
        };
        await setSession(jid, session);
        await sock.sendMessage(jid, { text: 'Survey started. What is your name?' });
      }
      break;

    case '/death':
    case '.death':
      await handleDeathCommand(sock, jid, args, rawMsg);
      break;

    case '/reports':
    case '.reports':
      await handleViewReports(sock, jid, args);
      break;

    case '/clearreports':
    case '.clearreports':
      await handleClearReports(sock, jid, args);
      break;

    default:
      await sock.sendMessage(jid, { text: `Unknown command: ${command}\nType .help for a list of commands.` });
  }
}

async function handleDeathCommand(sock, jid, args, rawMsg) {
  // Explicit refusal to automate harmful actions
  // Provide a safe alternative: store moderated reports in Redis for owner review
  if (!args || args.length === 0) {
    await sock.sendMessage(jid, {
      text:
        'Usage: .death <phone_or_jid> [reason]\n' +
        'Important: This command does NOT perform mass-reporting or any abusive action. ' +
        'It records a moderated incident report so the bot owner/admins can review and take appropriate steps.\n' +
        'Example: .death 1234567890 "spamming and threats"'
    });
    return;
  }

  // parse target
  let target = args[0].trim();
  // normalize: if looks like phone number, add @s.whatsapp.net
  if (!target.includes('@')) {
    // remove any non-digit characters
    const digits = target.replace(/\D/g, '');
    if (!digits) {
      await sock.sendMessage(jid, { text: 'Could not parse target. Provide a phone number or full JID.' });
      return;
    }
    target = `${digits}@s.whatsapp.net`;
  }

  const reason = args.slice(1).join(' ').trim() || 'No reason provided';

  // Add the report to store with rate limits enforced in reportsStore
  const res = await reportsStore.addReport(target, jid, reason);

  if (!res.success && res.reason === 'rate_limited') {
    await sock.sendMessage(jid, {
      text:
        'You are sending reports too quickly. Please wait before reporting again. ' +
        `Rate limit: ${reportsStore.MAX_PER_MINUTE} reports per ${reportsStore.RATE_WINDOW_SECONDS} seconds.`
    });
    return;
  }

  if (!res.success) {
    await sock.sendMessage(jid, { text: 'Failed to record report. Please try again later.' });
    return;
  }

  // Confirm to the reporter
  await sock.sendMessage(jid, {
    text:
      `Thanks. Your incident report for ${target} was recorded (report id: ${res.id}).\n` +
      `Total stored reports for this contact: ${res.count}.\n\n` +
      'Note: This only records a report for owner/moderator review; it does not send mass reports or perform destructive actions.'
  });

  // If stored reports exceed a configurable threshold, optionally notify owner
  const notifyThreshold = process.env.REPORT_NOTIFY_THRESHOLD ? parseInt(process.env.REPORT_NOTIFY_THRESHOLD, 10) : 10;
  if (res.count >= notifyThreshold) {
    try {
      await sock.sendMessage(process.env.OWNER_JID || '237696777393@s.whatsapp.net', {
        text:
          `⚠️ Report threshold reached for ${target}.\n` +
          `Reports stored: ${res.count}\n` +
          `Last reporter: ${jid}\n` +
          `Last reason: ${reason}\n` +
          `Use .reports ${target.replace('@s.whatsapp.net','')} to inspect.`
      });
    } catch (err) {
      console.error('Failed to notify owner about report threshold', err);
    }
  }
}

async function handleViewReports(sock, jid, args) {
  if ((process.env.OWNER_JID || '237696777393@s.whatsapp.net') !== jid) {
    await sock.sendMessage(jid, { text: 'Only the bot owner may view stored reports.' });
    return;
  }
  if (!args || !args[0]) {
    await sock.sendMessage(jid, { text: 'Usage: .reports <number|jid>' });
    return;
  }
  let target = args[0].trim();
  if (!target.includes('@')) {
    const digits = target.replace(/\D/g, '');
    target = `${digits}@s.whatsapp.net`;
  }
  const items = await reportsStore.getReports(target);
  if (!items || items.length === 0) {
    await sock.sendMessage(jid, { text: `No stored reports for ${target}.` });
    return;
  }

  const lines = items.slice(0, 50).map((r, i) => {
    const time = new Date(r.ts).toISOString();
    return `${i + 1}. id:${r.id} reporter:${r.reporter} time:${time} reason:${r.reason}`;
  });

  await sock.sendMessage(jid, {
    text:
      `Stored reports for ${target} (showing ${lines.length} of ${items.length}):\n\n` +
      lines.join('\n')
  });
}

async function handleClearReports(sock, jid, args) {
  if ((process.env.OWNER_JID || '237696777393@s.whatsapp.net') !== jid) {
    await sock.sendMessage(jid, { text: 'Only the bot owner may clear stored reports.' });
    return;
  }
  if (!args || !args[0]) {
    await sock.sendMessage(jid, { text: 'Usage: .clearreports <number|jid>' });
    return;
  }
  let target = args[0].trim();
  if (!target.includes('@')) {
    const digits = target.replace(/\D/g, '');
    target = `${digits}@s.whatsapp.net`;
  }
  await reportsStore.clearReports(target);
  await sock.sendMessage(jid, { text: `Cleared stored reports for ${target}.` });
}

/**
 * handleSessionMessage(sock, jid, messageText, session)
 * Processes the message within the context of the active session.
 * Returns: true if session should continue (and has been saved/updated), false if session finished and should be cleared.
 */
async function handleSessionMessage(sock, jid, messageText, session) {
  if (!session || !session.command) return false;

  switch (session.command) {
    case 'survey':
      return await handleSurveyFlow(sock, jid, messageText, session);

    default:
      // unknown session type -> end it
      await sock.sendMessage(jid, { text: 'Unknown session state, ending session.' });
      return false;
  }
}

async function handleSurveyFlow(sock, jid, messageText, session) {
  if (session.step === 1) {
    // save name
    session.data.name = messageText.trim();
    session.step = 2;
    await setSession(jid, session);
    await sock.sendMessage(jid, { text: `Nice to meet you, ${session.data.name}! How old are you? (please send a number)` });
    return true;
  }

  if (session.step === 2) {
    const ageText = messageText.trim();
    const age = parseInt(ageText, 10);
    if (Number.isNaN(age) || age <= 0) {
      await sock.sendMessage(jid, { text: 'Please enter a valid age as a number (e.g., 28).' });
      return true; // keep the session
    }
    session.data.age = age;
    // finished
    await sock.sendMessage(jid, {
      text: `Survey complete!\nName: ${session.data.name}\nAge: ${session.data.age}\nThank you!`
    });
    // optionally process/store the data here (DB, analytics, etc.)
    return false; // signal to clear session
  }

  // fallback: end session
  await sock.sendMessage(jid, { text: 'Session error, ending.' });
  return false;
}

module.exports = {
  handleCommand,
  handleSessionMessage
};