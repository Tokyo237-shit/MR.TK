// command-loader.js
// Loads command modules from ./commands and provides a registry.

const fs = require('fs');
const path = require('path');

const COMMANDS_DIR = path.join(__dirname, 'commands');

function loadCommands() {
  const commands = new Map();
  const categories = new Map();

  if (!fs.existsSync(COMMANDS_DIR)) {
    return { commands, categories };
  }

  const files = fs.readdirSync(COMMANDS_DIR).filter(f => f.endsWith('.js'));
  for (const file of files) {
    try {
      const full = path.join(COMMANDS_DIR, file);
      delete require.cache[require.resolve(full)];
      const cmd = require(full);
      if (!cmd || !cmd.name || typeof cmd.execute !== 'function') {
        console.warn(`Skipping ${file}: missing name or execute`);
        continue;
      }
      commands.set(cmd.name, cmd);
      if (Array.isArray(cmd.aliases)) {
        for (const a of cmd.aliases) commands.set(a, cmd);
      }
      const cat = cmd.category || 'misc';
      if (!categories.has(cat)) categories.set(cat, []);
      categories.get(cat).push(cmd);
    } catch (err) {
      console.error('Failed to load command', file, err);
    }
  }

  return { commands, categories };
}

module.exports = {
  loadCommands
};