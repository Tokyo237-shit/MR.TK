```markdown
# Baileys WhatsApp Bot with Redis Sessions

This project is a minimal WhatsApp bot using Baileys with:
- Command parsing for slash-style commands (e.g., /survey)
- Redis-backed session store so the bot can handle multi-step conversational flows
- Example "/survey" flow that asks for name and age then responds with a summary

## Files added
- index.js — main bot, routes inbound messages to commands or session handlers
- commands.js — command parsing and survey flow implementation
- sessionStore.js — Redis session helper (get/set/clear/touch)
- docker-compose.yml — bring up a Redis instance locally
- package.json — dependencies
- README.md, .env.example

## Requirements
- Node.js 16+
- A phone with WhatsApp to scan QR (for Baileys)
- Redis (local via docker-compose or remote via REDIS_URL)

## Quick start (local)
1. Install deps:
   ```
   npm install
   ```

2. Run Redis locally:
   ```
   docker-compose up -d
   ```

3. Create a .env file (see .env.example). At minimum you can leave Redis defaults if using docker-compose.

4. Start the bot:
   ```
   npm start
   ```

5. On first run you'll get a QR printed in the terminal. Scan it on your phone: WhatsApp -> Menu -> Linked devices -> Link a device.

6. Try commands:
   - Send "/survey" to start the two-step flow.
   - Send "/cancel" to cancel any active flow.
   - Send other text to get an echo.

## .env.example
```
# .env.example
# either use REDIS_URL or REDIS_HOST/REDIS_PORT
# REDIS_URL=redis://:password@host:6379/0
REDIS_HOST=127.0.0.1
REDIS_PORT=6379
# REDIS_PASSWORD=your_redis_password_if_any

# Session key prefix and TTL (optional)
SESSION_KEY_PREFIX=wa_session:
SESSION_TTL_SECONDS=300
```

## What I implemented
I wired a Redis-backed session store and command parsing into the Baileys echo bot skeleton. The example "/survey" flow demonstrates how to ask follow-up questions and persist state across messages so the bot can handle multi-step conversations from many users concurrently. Sessions expire after a TTL (default 5 minutes) and are touched (TTL refreshed) while active.

## Next steps you might take
- Persist completed survey responses to a database.
- Add richer message types (buttons, lists, media uploads).
- Add per-user rate limiting and spam protections.
- Dockerize the bot or add a process manager (PM2/systemd).
- Add authentication/ACL if you want commands limited to certain numbers.
```