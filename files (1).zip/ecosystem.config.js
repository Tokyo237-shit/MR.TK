module.exports = {
  apps: [
    {
      name: 'mr-tk-bot',
      script: './index.js',
      cwd: '/home/username/mr-tk-bot', // Set to the folder where you upload the bot
      instances: 1,
      autorestart: true,
      watch: false,
      max_memory_restart: '300M',
      env: {
        NODE_ENV: 'production'
      }
    }
  ]
};