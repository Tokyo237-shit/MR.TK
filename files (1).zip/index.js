// index.js
// Main bot: autoloads commands via command-loader and routes messages.

const path = require('path');
require('dotenv').config();

const {
  default: makeWASocket,
  DisconnectReason,
  useSingleFileAuthState,
  fetchLatestBaileysVersion
} = require('@adiwajshing/baileys');
const { Boom } = require('@hapi/boom');

const { loadCommands } = require('./command-loader');
const { getSession, setSession, clearSession, touchSession } = require('./sessionStore');

const authFile = path.join(__dirname, './auth_info.json');
const { state, saveState } = useSingleFileAuthState(authFile);

const OWNER_JID = (process.env.OWNER_JID || '237696777393@s.whatsapp.net').trim();

async function startSock() {
  const { version, isLatest } = await fetchLatestBaileysVersion();
  console.log('Using WA version', version.join('.'), 'isLatest:', isLatest);

  const sock = makeWASocket({
    version,
    auth: state,
    printQRInTerminal: true,
    logger: undefined,
  });

  // persist auth updates
  sock.ev.on('creds.update', saveState);

  // load commands
  let { commands, categories } = loadCommands();
  console.log(`Loaded ${[...new Set(commands.values())].length} command modules.`);

  sock.ev.on('contacts.upsert', () => { /* ignore */ });

  // We will reload commands on SIGHUP (useful during dev)
  process.on('SIGHUP', () => {
    const out = loadCommands();
    commands = out.commands;
    categories = out.categories;
    console.log('Commands reloaded via SIGHUP.');
  });

  // connection updates (qr, open, close)
  sock.ev.on('connection.update', (update) => {
    const { connection, lastDisconnect, qr } = update;
    if (qr) {
      console.log('QR code received - scan it with WhatsApp mobile app.');
    }
    if (connection === 'open') {
      console.log('Connected to WhatsApp Web');
    }
    if (connection === 'close') {
      const reason = lastDisconnect?.error
        ? (Boom.isBoom(lastDisconnect.error) ? lastDisconnect.error.output.statusCode : 'unknown')
        : 'unknown';
      console.log('Connection closed, reason:', reason);
      const statusCode = lastDisconnect?.error?.output?.statusCode;
      if (statusCode === DisconnectReason.loggedOut) {
        console.log('Logged out — delete auth_info.json and re-scan the QR.');
      } else {
        console.log('Reconnecting...');
        startSock().catch(err => console.error('Failed to restart socket', err));
      }
    }
  });

  // helper: check if jid looks like a group
  function isGroupJid(jid) {
    return typeof jid === 'string' && jid.endsWith('@g.us');
  }

  // helper: check if user is group admin (fetch metadata)
  async function isGroupAdmin(groupJid, userJid) {
    try {
      const meta = await sock.groupMetadata(groupJid);
      if (!meta || !Array.isArray(meta.participants)) return false;
      const p = meta.participants.find(x => x.id === userJid);
      if (!p) return false;
      return ['admin', 'superadmin'].includes(p.admin || '');
    } catch (err) {
      // failed to fetch metadata; default safe false
      return false;
    }
  }

  // handle incoming messages
  sock.ev.on('messages.upsert', async (m) => {
    try {
      const messages = m.messages || [];
      for (const msg of messages) {
        // skip updates without message or status broadcasts
        if (!msg.message || (msg.key && msg.key.remoteJid === 'status@broadcast')) continue;
        if (msg.key.fromMe) continue;

        const from = msg.key.remoteJid; // e.g., "123456789@s.whatsapp.net" or a group
        const isGroup = isGroupJid(from);

        // extract text from several possible message types
        const text =
          msg.message.conversation ||
          msg.message.extendedTextMessage?.text ||
          msg.message.imageMessage?.caption ||
          msg.message.videoMessage?.caption ||
          '';

        if (!text) continue;

        console.log('Received message from', from, ':', text);

        // session handling first
        const session = await getSession(from);
        if (session && session.command) {
          await touchSession(from);
          // session handlers are defined as commands with the same naming style
          // find session handler by name
          const sessionCmd = commands.get(session.command);
          if (sessionCmd && typeof sessionCmd.handleSession === 'function') {
            const context = {
              sock, jid: from, args: [text], raw: msg, isGroup, isOwner: from === OWNER_JID
            };
            const cont = await sessionCmd.handleSession(context, session);
            if (!cont) await clearSession(from);
            continue;
          }
        }

        // command parsing: accept both '.' and '/' prefixes
        const trimmed = text.trim();
        const isCommand = trimmed.startsWith('.') || trimmed.startsWith('/');
        if (isCommand) {
          const parts = trimmed.split(/\s+/);
          const rawCmd = parts[0].slice(1); // remove prefix
          const args = parts.slice(1);

          // find command by name or alias
          const cmd = commands.get(rawCmd.toLowerCase());
          if (!cmd) {
            await sock.sendMessage(from, { text: `Unknown command: ${rawCmd}\nType .help for a list of commands.` });
            continue;
          }

          // permission checks
          if (cmd.ownerOnly && (msg.key.participant || from) !== OWNER_JID) {
            await sock.sendMessage(from, { text: 'This command is owner-only.' });
            continue;
          }
          if (cmd.groupOnly && !isGroup) {
            await sock.sendMessage(from, { text: 'This command can only be used in groups.' });
            continue;
          }
          if (cmd.adminOnly && isGroup) {
            const user = msg.key.participant || msg.key.remoteJid || null;
            const isAdmin = await isGroupAdmin(from, user);
            if (!isAdmin && (user !== OWNER_JID)) {
              await sock.sendMessage(from, { text: 'This command requires group admin privileges.' });
              continue;
            }
          }

          // execute command
          try {
            await cmd.execute({
              sock,
              jid: from,
              args,
              raw: msg,
              isGroup,
              isOwner: (msg.key.participant || from) === OWNER_JID,
              reply: async (textOrMessage) => {
                if (typeof textOrMessage === 'string') {
                  return sock.sendMessage(from, { text: textOrMessage });
                } else {
                  return sock.sendMessage(from, textOrMessage);
                }
              }
            });
          } catch (err) {
            console.error('Command execution error', err);
            await sock.sendMessage(from, { text: `Command error: ${err.message || err}` });
          }

          continue;
        }

        // fallback: echo
        await sock.sendMessage(from, { text: `Echo: ${text}` });
      }
    } catch (err) {
      console.error('Error handling messages.upsert', err);
    }
  });

  return sock;
}

startSock().catch(err => {
  console.error('startSock error', err);
  process.exit(1);
});