#!/usr/bin/env bash
# start.sh - simple helper to prepare and start the bot on hosts that provide a terminal
# Make executable (chmod +x start.sh) if your control panel supports it.

set -e

# Install dependencies (production)
if [ -f package-lock.json ]; then
  npm ci --only=production
else
  npm install --only=production
fi

# Ensure .env exists
if [ ! -f .env ] && [ -f .env.production ]; then
  echo "Using .env.production as .env"
  cp .env.production .env
fi

# Create directories for persistent auth if not exist
mkdir -p data
# Move auth_info.json to data/auth_info.json if found in repo root (optional)
if [ -f auth_info.json ] && [ ! -f data/auth_info.json ]; then
  mv auth_info.json data/auth_info.json || true
fi

# Start the bot (simple)
node index.js