// reportsStore.js
// Safe, Redis-backed store for moderated incident reports (the non-abusive .death flow).

const IORedis = require('ioredis');
const redisUrl = process.env.REDIS_URL || null;

const redis = redisUrl ? new IORedis(redisUrl) : new IORedis({
  host: process.env.REDIS_HOST || '127.0.0.1',
  port: process.env.REDIS_PORT ? parseInt(process.env.REDIS_PORT, 10) : 6379,
  password: process.env.REDIS_PASSWORD || undefined,
});

// Rate limit: max reports a single reporter can submit per RATE_WINDOW_SECONDS
const RATE_WINDOW_SECONDS = process.env.REPORT_RATE_WINDOW_SECONDS ? parseInt(process.env.REPORT_RATE_WINDOW_SECONDS, 10) : 60;
const MAX_PER_WINDOW = process.env.REPORT_MAX_PER_WINDOW ? parseInt(process.env.REPORT_MAX_PER_WINDOW, 10) : 3;

// Keep up to this many reports per target
const MAX_REPORTS_PER_TARGET = process.env.REPORTS_MAX_PER_TARGET ? parseInt(process.env.REPORTS_MAX_PER_TARGET, 10) : 1000;

function reporterKey(reporterJid) {
  return `report_rate:${reporterJid}`;
}
function targetKey(targetJid) {
  return `reports:${targetJid}`;
}

async function addReport(targetJid, reporterJid, reason) {
  // Enforce reporter rate limit
  const rKey = reporterKey(reporterJid);
  const current = await redis.incr(rKey);
  if (current === 1) {
    await redis.expire(rKey, RATE_WINDOW_SECONDS);
  }
  if (current > MAX_PER_WINDOW) {
    return { success: false, reason: 'rate_limited' };
  }

  const id = `${Date.now()}:${Math.random().toString(36).slice(2,8)}`;
  const payload = JSON.stringify({ id, reporter: reporterJid, reason: reason || '', ts: Date.now() });
  const tKey = targetKey(targetJid);
  await redis.lpush(tKey, payload);
  await redis.ltrim(tKey, 0, MAX_REPORTS_PER_TARGET - 1);
  const count = await redis.llen(tKey);
  return { success: true, id, count };
}

async function getReports(targetJid) {
  const tKey = targetKey(targetJid);
  const raw = await redis.lrange(tKey, 0, -1);
  return raw.map(r => {
    try { return JSON.parse(r); } catch (e) { return { raw: r }; }
  });
}

async function clearReports(targetJid) {
  const tKey = targetKey(targetJid);
  await redis.del(tKey);
}

module.exports = {
  addReport,
  getReports,
  clearReports,
  MAX_PER_WINDOW,
  RATE_WINDOW_SECONDS,
  _redisClient: redis
};