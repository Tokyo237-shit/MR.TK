```markdown
# Deploying MR•TK Bot on a Control-Panel Host

This guide walks you through deploying the Baileys WhatsApp bot on a hosting provider that offers:
- A file manager / upload interface (zip upload + extract), and
- The ability to run Node processes (via "Run command", terminal, or process manager).

If your control panel offers SSH or a terminal, you can run the commands directly; otherwise use the control panel's run/cron/process UI.

Pre-flight checklist
- Make sure Node.js (>=16) is available on the host. If the control panel provides Node versions, pick a modern one (18/20 recommended).
- Use a managed Redis (recommended) or ensure Redis is available on the host. For most control-panel providers you will use an external/managed Redis such as Upstash, Redis Cloud, or your own VPS.
- Keep your auth file (auth_info.json) private. Do not commit it to Git or share it.

Files to upload
- All project files including index.js, commands/, package.json, sessionStore.js, reportsStore.js and the files in this bundle.
- Copy .env.production.example -> .env.production and edit values (set OWNER_JID and REDIS_URL preferrably)

Deployment steps

1) Prepare a ZIP locally
   - From your project root:
     ```
     zip -r mr-tk-bot.zip . -x node_modules/**\* data/**\* *.env
     ```
   - The zip excludes node_modules (install on host) and local env files.

2) Upload & extract
   - Use the control panel file manager to upload mr-tk-bot.zip into a folder (e.g., /home/youruser/mr-tk-bot).
   - Extract the zip.

3) Create environment file
   - In the project folder create a `.env.production` (or `.env`) file using `.env.production.example` as template.
   - Important values:
     - OWNER_JID=237696777393@s.whatsapp.net
     - Use REDIS_URL=redis://:password@host:port/0 if your provider supports it (recommended).

4) Install dependencies
   - If your control panel allows running commands, run:
     ```
     cd /path/to/mr-tk-bot
     npm ci --only=production
     ```
   - If no command execution is available, many control panels provide a “Install Dependencies” or “Node.js App” button — use that to run npm install.

5) Persist auth file (auth_info.json)
   - The bot will create `auth_info.json` after first successful QR scan.
   - Ensure your control panel does not clear uploaded files on restarts. If there's a persistent storage or "data" directory, move or symlink `auth_info.json` there after the first run.
   - Example: after first QR scan finishes, create a folder `data` and move `auth_info.json` to `data/auth_info.json`.

6) Start the bot
   Option A — Simple run (if panel provides a "Run" button)
     - Run: `node index.js`
     - View logs as allowed by your control panel to scan the QR code on first run (QR is printed to stdout).

   Option B — Use PM2 (recommended if available)
     - Install pm2 (once): `npm install -g pm2`
     - Start via config: `pm2 start ecosystem.config.js --env production`
     - Save startup: `pm2 save`
     - Follow `pm2 startup` instructions to enable auto-start on server boot.

   Option C — Use the control panel's Node process manager
     - Many panels let you choose the start command and environment file. Set:
       - Start command: `node index.js` (or `npm start` if package.json configured)
       - Working directory: project folder
       - Environment file: `.env.production`
     - Start the process from the UI and inspect logs.

7) First-run: scanning the QR
   - On first run the bot prints a QR to stdout / logs. Use the panel's log viewer (or terminal) to locate and scan the QR with your WhatsApp phone:
     - Open WhatsApp → Settings → Linked devices → Link a device → Scan the QR.
   - After successful auth, `auth_info.json` will be created and saved.

8) Using Redis
   - Recommended: use a managed Redis and set REDIS_URL in .env.production.
   - Example Upstash: `REDIS_URL=redis://:your_token@us1-upstash.example/0`
   - If your host provides a Redis service, set REDIS_HOST and REDIS_PORT.

9) Backups & security
   - Backup `data/auth_info.json` regularly.
   - Do not commit `.env` files or `auth_info.json` to Git.
   - Use a secrets manager if your control panel supports it.

10) Common troubleshooting
   - No QR in logs: ensure the process' stdout/stderr is accessible in the control panel.
   - Bot not starting: check Node version and that `npm ci` succeeded.
   - Redis connection errors: verify REDIS_URL, username/password, and firewall rules.

If you'd like, I can:
- Produce a zip containing exactly the files needed (I can't upload it for you, but I can print the files so you can copy them).
- Provide a ready-made `.env.production` with REDIS_URL pointing to Upstash if you create an Upstash instance and paste the URL here.
- Give the exact command sequence for your control panel if you tell me the panel name (cPanel, Plesk, CyberPanel, etc.) so I can tailor the instructions.
